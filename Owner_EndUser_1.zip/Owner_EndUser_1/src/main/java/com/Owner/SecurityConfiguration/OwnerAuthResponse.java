package com.Owner.SecurityConfiguration;

public class OwnerAuthResponse {
	private String Response;

	public String getResponse() {
		return Response;
	}

	public void setResponse(String response) {
		Response = response;

	}

	public OwnerAuthResponse(String response) {
		
		Response = response;
	}

	public OwnerAuthResponse() {
	
		
	}
	

}
