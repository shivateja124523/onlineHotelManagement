package com.Manager.Models;

import java.util.List;

public class StaffList {

	private List<Staff> allEmp;

	public List<Staff> getAllEmp() {
		return allEmp;
	}

	public void setAllEmp(List<Staff> allEmp) {
		this.allEmp = allEmp;
	}

}