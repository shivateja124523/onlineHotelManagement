package com.Manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagerEndUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
