package com.Manager.SecurityConfiguration;

public class ManagerAuthResponse {

	private String Response;

	public String getResponse() {
		return Response;
	}

	public void setResponse(String response) {
		Response = response;

	}

	public ManagerAuthResponse(String response) {

		Response = response;
	}

	public ManagerAuthResponse() {

	}

}
