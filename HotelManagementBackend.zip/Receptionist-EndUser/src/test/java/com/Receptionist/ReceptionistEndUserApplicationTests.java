package com.Receptionist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceptionistEndUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
