/*
 * package com.Receptionist.SecurityConfiguration;
 * 
 * public class ReceptionistAuthResponse {
 * 
 * private String Response;
 * 
 * public String getResponse() { return Response; }
 * 
 * public void setResponse(String response) { Response = response;
 * 
 * }
 * 
 * public ReceptionistAuthResponse(String response) {
 * 
 * Response = response; }
 * 
 * public ReceptionistAuthResponse() {
 * 
 * }
 * 
 * }
 */