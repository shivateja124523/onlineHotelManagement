package com.payment.Model;

import java.util.List;



public class PaymentList {
	private List<Payment> allPay;

	public List<Payment> getAllPayment() {
		return allPay;
	}

	public void setAllpay(List<Payment> allPay) {
		this.allPay = allPay;
	}

}
