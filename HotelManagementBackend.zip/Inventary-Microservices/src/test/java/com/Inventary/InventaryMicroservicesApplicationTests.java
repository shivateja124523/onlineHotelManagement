package com.Inventary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventaryMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
